-- Crea la base de datos si no existe
CREATE DATABASE IF NOT EXISTS ejemploBBDD;

-- Selecciona la base de datos
USE ejemploBBDD;

-- Elimina las tablas si existen
DROP TABLE IF EXISTS mediciones;
DROP TABLE IF EXISTS sensores;
DROP TABLE IF EXISTS senusu;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS usro;
DROP TABLE IF EXISTS roles;

-- Tabla de roles
CREATE TABLE IF NOT EXISTS roles (
  id_rol INT AUTO_INCREMENT PRIMARY KEY,
  descripcion VARCHAR(50) NOT NULL
);

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  telefono VARCHAR(15) NOT NULL,
  correo VARCHAR(255) NOT NULL,
  contrasena VARCHAR(255) NOT NULL
);

-- Tabla usuario-roles
CREATE TABLE IF NOT EXISTS usro (
  id_usuario INT NOT NULL,
  id_rol INT NOT NULL,
  PRIMARY KEY (id_usuario, id_rol),
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario),
  FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
);

-- Tabla de sensores
CREATE TABLE IF NOT EXISTS sensores (
  id_sensor VARCHAR(17) PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  funciona BOOLEAN NOT NULL
);

-- Tabla sensores-usuarios
CREATE TABLE IF NOT EXISTS senusu (
  id_sensor VARCHAR(17) NOT NULL,
  id_usuario INT NOT NULL,
  PRIMARY KEY (id_sensor, id_usuario),
  FOREIGN KEY (id_sensor) REFERENCES sensores(id_sensor),
  FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
);

-- Tabla de mediciones
CREATE TABLE IF NOT EXISTS mediciones (
  id_medicion INT AUTO_INCREMENT PRIMARY KEY,
  id_sensor VARCHAR(17) NOT NULL,
  fecha_hora DATETIME NOT NULL,
  ubicacion JSON NOT NULL,
  tipo_medicion VARCHAR(50) NOT NULL, 
  valor DECIMAL(5, 2) NOT NULL,
  FOREIGN KEY (id_sensor) REFERENCES sensores(id_sensor)
);

-- Datos de ejemplo de la tabla roles
INSERT INTO roles (id_rol, descripcion) VALUES
 (1, 'Administrador'),
 (2, 'Usuario'),
 (3, 'Tecnico');

-- Datos de ejemplo de la tabla usuarios
INSERT INTO usuarios (nombre, telefono, correo, contrasena) VALUES
('Vicente', '601037577', 'visi02@gmail.com', 'pass1'),
('Irene', '661781764', 'irene08@gmail.com', 'pass2'),
('Mimi', '643472723', 'mimi04@gmail.com', 'pass3'),
('Pablo', '625932402', 'pablo06@gmail.com', 'pass4'),
('Yilun', '657225314', 'yilun10@gmail.com', 'pass5');

-- Datos de ejemplo de la tabla usuario-roles
INSERT INTO usro (id_usuario, id_rol) VALUES
  (1, 2),
  (2, 1),
  (3, 1),
  (4, 1),
  (5, 1),
  (1, 1);

-- Datos de ejemplo de la tabla sensores
INSERT INTO sensores (id_sensor, nombre, funciona) VALUES
  ('00:1A:2B:3M:4D:5E', 'Sensor 1', TRUE),
  ('11:2B:2X:3L:4K:5F', 'Sensor 2', TRUE),
  ('22:3C:2T:3U:4H:5G', 'Sensor 3', TRUE),
  ('33:4A:2R:3Q:4G:5H', 'Sensor 4', TRUE),
  ('44:5C:2V:3S:4F:6I', 'Sensor 5', TRUE);


-- Datos de ejemplo de la tabla sensores-usuarios
INSERT INTO senusu (id_sensor, id_usuario) VALUES
  ('00:1A:2B:3M:4D:5E', 1), 
  ('11:2B:2X:3L:4K:5F', 2),
  ('22:3C:2T:3U:4H:5G', 3),
  ('33:4A:2R:3Q:4G:5H', 4),
  ('44:5C:2V:3S:4F:6I', 5);

-- Datos de ejemplo de la tabla mediciones
INSERT INTO mediciones (id_sensor, fecha_hora, ubicacion, tipo_medicion, valor) VALUES
-- 00:1A:2B:3M:4D:5E 39.020883434197344, -0.1751796709114592
('00:1A:2B:3M:4D:5E', '2024-12-08 08:00:00', '{"latitud": 39.0208, "longitud": -0.1751}', 'Temperatura', 12.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 08:00:00', '{"latitud": 39.0208, "longitud": -0.1751}', 'SO3', 76.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 08:00:00', '{"latitud": 39.0208, "longitud": -0.1751}', 'NO2', 35.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 08:00:00', '{"latitud": 39.0208, "longitud": -0.1751}', 'O3', 80.0),
-- 39.015070896543456, -0.1787751501099645
('00:1A:2B:3M:4D:5E', '2024-12-08 09:00:00', '{"latitud": 39.0150, "longitud": -0.1787}', 'Temperatura', 11.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 09:00:00', '{"latitud": 39.0150, "longitud": -0.1787}', 'SO3', 74.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 09:00:00', '{"latitud": 39.0150, "longitud": -0.1787}', 'NO2', 36.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 09:00:00', '{"latitud": 39.0150, "longitud": -0.1787}', 'O3', 75.0),
-- 39.01506489067093, -0.1709035364122068
('00:1A:2B:3M:4D:5E', '2024-12-08 10:00:00', '{"latitud": 39.0170, "longitud": -0.1709}', 'Temperatura', 15.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 10:00:00', '{"latitud": 39.0170, "longitud": -0.1709}', 'SO3', 70.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 10:00:00', '{"latitud": 39.0170, "longitud": -0.1709}', 'NO2', 30.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 10:00:00', '{"latitud": 39.0170, "longitud": -0.1709}', 'O3', 85.0),
-- 
('00:1A:2B:3M:4D:5E', '2024-12-08 11:00:00', '{"latitud": 39.0150, "longitud": -0.1720}', 'Temperatura', 14.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 11:00:00', '{"latitud": 39.0150, "longitud": -0.1720}', 'SO3', 72.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 11:00:00', '{"latitud": 39.0150, "longitud": -0.1720}', 'NO2', 32.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 11:00:00', '{"latitud": 39.0150, "longitud": -0.1720}', 'O3', 90.0),
--
('00:1A:2B:3M:4D:5E', '2024-12-08 12:00:00', '{"latitud": 39.0160, "longitud": -0.1711}', 'Temperatura', 13.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 12:00:00', '{"latitud": 39.0160, "longitud": -0.1711}', 'SO3', 74.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 12:00:00', '{"latitud": 39.0160, "longitud": -0.1711}', 'NO2', 34.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 12:00:00', '{"latitud": 39.0160, "longitud": -0.1711}', 'O3', 95.0),
--
('00:1A:2B:3M:4D:5E', '2024-12-08 13:00:00', '{"latitud": 39.0163, "longitud": -0.1709}', 'Temperatura', 12.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 13:00:00', '{"latitud": 39.0163, "longitud": -0.1709}', 'SO3', 76.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 13:00:00', '{"latitud": 39.0163, "longitud": -0.1709}', 'NO2', 36.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 13:00:00', '{"latitud": 39.0163, "longitud": -0.1709}', 'O3', 100.0),
--
('00:1A:2B:3M:4D:5E', '2024-12-08 14:00:00', '{"latitud": 39.0150, "longitud": -0.1715}', 'Temperatura', 11.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 14:00:00', '{"latitud": 39.0150, "longitud": -0.1715}', 'SO3', 78.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 14:00:00', '{"latitud": 39.0150, "longitud": -0.1715}', 'NO2', 38.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 14:00:00', '{"latitud": 39.0150, "longitud": -0.1715}', 'O3', 105.0),
--
('00:1A:2B:3M:4D:5E', '2024-12-08 15:00:00', '{"latitud": 39.0180, "longitud": -0.1723}', 'Temperatura', 10.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 15:00:00', '{"latitud": 39.0180, "longitud": -0.1723}', 'SO3', 80.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 15:00:00', '{"latitud": 39.0180, "longitud": -0.1723}', 'NO2', 40.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 15:00:00', '{"latitud": 39.0180, "longitud": -0.1723}', 'O3', 110.0),
--
('00:1A:2B:3M:4D:5E', '2024-12-08 16:00:00', '{"latitud": 39.0172, "longitud": -0.1711}', 'Temperatura', 9.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 16:00:00', '{"latitud": 39.0172, "longitud": -0.1711}', 'SO3', 82.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 16:00:00', '{"latitud": 39.0172, "longitud": -0.1711}', 'NO2', 42.0),
('00:1A:2B:3M:4D:5E', '2024-12-08 16:00:00', '{"latitud": 39.0172, "longitud": -0.1711}', 'O3', 115.0),



-- 11:2B:2X:3L:4K:5F
('11:2B:2X:3L:4K:5F', '2024-12-08 00:00:00', '{"latitud": 38.7550, "longitud": -0.1710}', 'Temperatura', 18.0),
('11:2B:2X:3L:4K:5F', '2024-12-08 01:00:00', '{"latitud": 38.7552, "longitud": -0.1785}', 'SO3', 56.0),
('11:2B:2X:3L:4K:5F', '2024-12-08 02:00:00', '{"latitud": 38.7555, "longitud": -0.1780}', 'NO2', 66.0),
('11:2B:2X:3L:4K:5F', '2024-12-08 03:00:00', '{"latitud": 38.7557, "longitud": -0.1775}', 'O3', 142.0),
--
('11:2B:2X:3L:4K:5F', '2024-12-09 00:00:00', '{"latitud": 38.7560, "longitud": -0.1770}', 'Temperatura', 18.5),
('11:2B:2X:3L:4K:5F', '2024-12-09 01:00:00', '{"latitud": 38.7562, "longitud": -0.1765}', 'SO3', 57.0),
('11:2B:2X:3L:4K:5F', '2024-12-09 02:00:00', '{"latitud": 38.7565, "longitud": -0.1760}', 'NO2', 67.0),
('11:2B:2X:3L:4K:5F', '2024-12-09 03:00:00', '{"latitud": 38.7567, "longitud": -0.1755}', 'O3', 144.0),
--
('11:2B:2X:3L:4K:5F', '2024-12-10 00:00:00', '{"latitud": 38.7570, "longitud": -0.1750}', 'Temperatura', 19.0),
('11:2B:2X:3L:4K:5F', '2024-12-10 01:00:00', '{"latitud": 38.7572, "longitud": -0.1745}', 'SO3', 58.0),
('11:2B:2X:3L:4K:5F', '2024-12-10 02:00:00', '{"latitud": 38.7575, "longitud": -0.1740}', 'NO2', 68.0),
('11:2B:2X:3L:4K:5F', '2024-12-10 03:00:00', '{"latitud": 38.7577, "longitud": -0.1735}', 'O3', 146.0),
--
('11:2B:2X:3L:4K:5F', '2024-12-11 00:00:00', '{"latitud": 38.7580, "longitud": -0.1730}', 'Temperatura', 19.5),
('11:2B:2X:3L:4K:5F', '2024-12-11 01:00:00', '{"latitud": 38.7582, "longitud": -0.1725}', 'SO3', 59.0),
('11:2B:2X:3L:4K:5F', '2024-12-11 02:00:00', '{"latitud": 38.7585, "longitud": -0.1720}', 'NO2', 69.0),
('11:2B:2X:3L:4K:5F', '2024-12-11 03:00:00', '{"latitud": 38.7587, "longitud": -0.1715}', 'O3', 148.0),
--
('11:2B:2X:3L:4K:5F', '2024-12-12 00:00:00', '{"latitud": 38.7590, "longitud": -0.1710}', 'Temperatura', 20.0),
('11:2B:2X:3L:4K:5F', '2024-12-12 01:00:00', '{"latitud": 38.7592, "longitud": -0.1705}', 'SO3', 60.0),
('11:2B:2X:3L:4K:5F', '2024-12-12 02:00:00', '{"latitud": 38.7595, "longitud": -0.1700}', 'NO2', 70.0),
('11:2B:2X:3L:4K:5F', '2024-12-12 03:00:00', '{"latitud": 38.7597, "longitud": -0.1695}', 'O3', 150.0),
--
('11:2B:2X:3L:4K:5F', '2024-12-13 00:00:00', '{"latitud": 38.7600, "longitud": -0.1690}', 'Temperatura', 20.5),
('11:2B:2X:3L:4K:5F', '2024-12-13 01:00:00', '{"latitud": 38.7602, "longitud": -0.1685}', 'SO3', 61.0),
('11:2B:2X:3L:4K:5F', '2024-12-13 02:00:00', '{"latitud": 38.7605, "longitud": -0.1680}', 'NO2', 71.0),
('11:2B:2X:3L:4K:5F', '2024-12-13 03:00:00', '{"latitud": 38.7607, "longitud": -0.1675}', 'O3', 152.0),
--
-- 22:3C:2T:3U:4H:5G
('22:3C:2T:3U:4H:5G', '2024-12-08 00:00:00', '{"latitud": 38.7610, "longitud": -0.1670}', 'Temperatura', 21.0),
('22:3C:2T:3U:4H:5G', '2024-12-08 01:00:00', '{"latitud": 38.7612, "longitud": -0.1665}', 'SO3', 62.0),
('22:3C:2T:3U:4H:5G', '2024-12-08 02:00:00', '{"latitud": 38.7615, "longitud": -0.1660}', 'NO2', 72.0),
('22:3C:2T:3U:4H:5G', '2024-12-08 03:00:00', '{"latitud": 38.7617, "longitud": -0.1655}', 'O3', 154.0),
--
('22:3C:2T:3U:4H:5G', '2024-12-09 00:00:00', '{"latitud": 38.7620, "longitud": -0.1650}', 'Temperatura', 21.5),
('22:3C:2T:3U:4H:5G', '2024-12-09 01:00:00', '{"latitud": 38.7622, "longitud": -0.1645}', 'SO3', 63.0),
('22:3C:2T:3U:4H:5G', '2024-12-09 02:00:00', '{"latitud": 38.7625, "longitud": -0.1640}', 'NO2', 73.0),
('22:3C:2T:3U:4H:5G', '2024-12-09 03:00:00', '{"latitud": 38.7627, "longitud": -0.1635}', 'O3', 156.0),
--
('22:3C:2T:3U:4H:5G', '2024-12-10 00:00:00', '{"latitud": 38.7630, "longitud": -0.1630}', 'Temperatura', 22.0),
('22:3C:2T:3U:4H:5G', '2024-12-10 01:00:00', '{"latitud": 38.7632, "longitud": -0.1625}', 'SO3', 64.0),
('22:3C:2T:3U:4H:5G', '2024-12-10 02:00:00', '{"latitud": 38.7635, "longitud": -0.1620}', 'NO2', 74.0),
('22:3C:2T:3U:4H:5G', '2024-12-10 03:00:00', '{"latitud": 38.7637, "longitud": -0.1615}', 'O3', 158.0),
--
('22:3C:2T:3U:4H:5G', '2024-12-11 00:00:00', '{"latitud": 38.7640, "longitud": -0.1610}', 'Temperatura', 22.5),
('22:3C:2T:3U:4H:5G', '2024-12-11 01:00:00', '{"latitud": 38.7642, "longitud": -0.1605}', 'SO3', 65.0),
('22:3C:2T:3U:4H:5G', '2024-12-11 02:00:00', '{"latitud": 38.7645, "longitud": -0.1600}', 'NO2', 75.0),
('22:3C:2T:3U:4H:5G', '2024-12-11 03:00:00', '{"latitud": 38.7649, "longitud": -0.1595}', 'NO2', 70.0),
-- 
('22:3C:2T:3U:4H:5G', '2024-12-12 00:00:00', '{"latitud": 38.7650, "longitud": -0.1590}', 'Temperatura', 23.0),
('22:3C:2T:3U:4H:5G', '2024-12-12 01:00:00', '{"latitud": 38.7652, "longitud": -0.1585}', 'SO3', 66.0),
('22:3C:2T:3U:4H:5G', '2024-12-12 02:00:00', '{"latitud": 38.7655, "longitud": -0.1580}', 'NO2', 76.0),
('22:3C:2T:3U:4H:5G', '2024-12-12 03:00:00', '{"latitud": 38.7657, "longitud": -0.1575}', 'O3', 160.0),
--
-- 33:4A:2R:3Q:4G:5H
('33:4A:2R:3Q:4G:5H', '2024-12-08 00:00:00', '{"latitud": 38.7660, "longitud": -0.1570}', 'Temperatura', 23.5),
('33:4A:2R:3Q:4G:5H', '2024-12-08 01:00:00', '{"latitud": 38.7662, "longitud": -0.1565}', 'SO3', 67.0),
('33:4A:2R:3Q:4G:5H', '2024-12-08 02:00:00', '{"latitud": 38.7665, "longitud": -0.1560}', 'NO2', 77.0),
('33:4A:2R:3Q:4G:5H', '2024-12-08 03:00:00', '{"latitud": 38.7667, "longitud": -0.1555}', 'O3', 162.0),
--
('33:4A:2R:3Q:4G:5H', '2024-12-09 00:00:00', '{"latitud": 38.7670, "longitud": -0.1550}', 'Temperatura', 24.0),
('33:4A:2R:3Q:4G:5H', '2024-12-09 01:00:00', '{"latitud": 38.7672, "longitud": -0.1545}', 'SO3', 68.0),
('33:4A:2R:3Q:4G:5H', '2024-12-09 02:00:00', '{"latitud": 38.7675, "longitud": -0.1540}', 'NO2', 78.0),
('33:4A:2R:3Q:4G:5H', '2024-12-09 03:00:00', '{"latitud": 38.7677, "longitud": -0.1535}', 'O3', 164.0),
--
('33:4A:2R:3Q:4G:5H', '2024-12-10 00:00:00', '{"latitud": 38.7680, "longitud": -0.1530}', 'Temperatura', 24.5),
('33:4A:2R:3Q:4G:5H', '2024-12-10 01:00:00', '{"latitud": 38.7682, "longitud": -0.1525}', 'SO3', 69.0),
('33:4A:2R:3Q:4G:5H', '2024-12-10 02:00:00', '{"latitud": 38.7685, "longitud": -0.1520}', 'NO2', 79.0),
('33:4A:2R:3Q:4G:5H', '2024-12-10 03:00:00', '{"latitud": 38.7687, "longitud": -0.1515}', 'O3', 166.0),
--
('33:4A:2R:3Q:4G:5H', '2024-12-11 00:00:00', '{"latitud": 38.7690, "longitud": -0.1510}', 'Temperatura', 25.0),
('33:4A:2R:3Q:4G:5H', '2024-12-11 01:00:00', '{"latitud": 38.7692, "longitud": -0.1505}', 'SO3', 70.0),
('33:4A:2R:3Q:4G:5H', '2024-12-11 02:00:00', '{"latitud": 38.7695, "longitud": -0.1500}', 'NO2', 80.0),
('33:4A:2R:3Q:4G:5H', '2024-12-11 03:00:00', '{"latitud": 38.7697, "longitud": -0.1495}', 'O3', 168.0),
--
('33:4A:2R:3Q:4G:5H', '2024-12-12 00:00:00', '{"latitud": 38.7700, "longitud": -0.1490}', 'Temperatura', 25.5),
('33:4A:2R:3Q:4G:5H', '2024-12-12 01:00:00', '{"latitud": 38.7702, "longitud": -0.1485}', 'SO3', 71.0),
('33:4A:2R:3Q:4G:5H', '2024-12-12 02:00:00', '{"latitud": 38.7705, "longitud": -0.1480}', 'NO2', 81.0),
('33:4A:2R:3Q:4G:5H', '2024-12-12 03:00:00', '{"latitud": 38.7707, "longitud": -0.1475}', 'O3', 170.0),
--
('33:4A:2R:3Q:4G:5H', '2024-12-13 00:00:00', '{"latitud": 38.7710, "longitud": -0.1470}', 'Temperatura', 26.0),
('33:4A:2R:3Q:4G:5H', '2024-12-13 01:00:00', '{"latitud": 38.7712, "longitud": -0.1465}', 'SO3', 72.0),
('33:4A:2R:3Q:4G:5H', '2024-12-13 02:00:00', '{"latitud": 38.7715, "longitud": -0.1460}', 'NO2', 82.0),
('33:4A:2R:3Q:4G:5H', '2024-12-13 03:00:00', '{"latitud": 38.7717, "longitud": -0.1455}', 'O3', 172.0),
--
-- 44:5C:2V:3S:4F:6I
('44:5C:2V:3S:4F:6I', '2024-12-08 00:00:00', '{"latitud": 38.7720, "longitud": -0.1450}', 'Temperatura', 26.5),
('44:5C:2V:3S:4F:6I', '2024-12-08 01:00:00', '{"latitud": 38.7722, "longitud": -0.1445}', 'SO3', 73.0),
('44:5C:2V:3S:4F:6I', '2024-12-08 02:00:00', '{"latitud": 38.7725, "longitud": -0.1440}', 'NO2', 83.0),
('44:5C:2V:3S:4F:6I', '2024-12-08 03:00:00', '{"latitud": 38.7727, "longitud": -0.1435}', 'O3', 174.0),
--
('44:5C:2V:3S:4F:6I', '2024-12-09 00:00:00', '{"latitud": 38.7730, "longitud": -0.1430}', 'Temperatura', 27.0),
('44:5C:2V:3S:4F:6I', '2024-12-09 01:00:00', '{"latitud": 38.7732, "longitud": -0.1425}', 'SO3', 74.0),
('44:5C:2V:3S:4F:6I', '2024-12-09 02:00:00', '{"latitud": 38.7735, "longitud": -0.1420}', 'NO2', 84.0),
('44:5C:2V:3S:4F:6I', '2024-12-09 03:00:00', '{"latitud": 38.7737, "longitud": -0.1415}', 'O3', 176.0),
--
('44:5C:2V:3S:4F:6I', '2024-12-10 00:00:00', '{"latitud": 38.7740, "longitud": -0.1410}', 'Temperatura', 27.5),
('44:5C:2V:3S:4F:6I', '2024-12-10 01:00:00', '{"latitud": 38.7742, "longitud": -0.1405}', 'SO3', 75.0),
('44:5C:2V:3S:4F:6I', '2024-12-10 02:00:00', '{"latitud": 38.7745, "longitud": -0.1400}', 'NO2', 85.0),
('44:5C:2V:3S:4F:6I', '2024-12-10 03:00:00', '{"latitud": 38.7747, "longitud": -0.1395}', 'O3', 178.0),
--
('44:5C:2V:3S:4F:6I', '2024-12-11 00:00:00', '{"latitud": 38.7750, "longitud": -0.1390}', 'Temperatura', 28.0),
('44:5C:2V:3S:4F:6I', '2024-12-11 01:00:00', '{"latitud": 38.7752, "longitud": -0.1385}', 'SO3', 76.0),
('44:5C:2V:3S:4F:6I', '2024-12-11 02:00:00', '{"latitud": 38.7755, "longitud": -0.1380}', 'NO2', 86.0),
('44:5C:2V:3S:4F:6I', '2024-12-11 03:00:00', '{"latitud": 38.7757, "longitud": -0.1375}', 'O3', 180.0),
--
('44:5C:2V:3S:4F:6I', '2024-12-12 00:00:00', '{"latitud": 38.7760, "longitud": -0.1370}', 'Temperatura', 28.5),
('44:5C:2V:3S:4F:6I', '2024-12-12 01:00:00', '{"latitud": 38.7762, "longitud": -0.1365}', 'SO3', 77.0),
('44:5C:2V:3S:4F:6I', '2024-12-12 02:00:00', '{"latitud": 38.7765, "longitud": -0.1360}', 'NO2', 87.0),
('44:5C:2V:3S:4F:6I', '2024-12-12 03:00:00', '{"latitud": 38.7767, "longitud": -0.1355}', 'O3', 182.0),
--
('44:5C:2V:3S:4F:6I', '2024-12-13 00:00:00', '{"latitud": 38.7770, "longitud": -0.1350}', 'Temperatura', 29.0),
('44:5C:2V:3S:4F:6I', '2024-12-13 01:00:00', '{"latitud": 38.7772, "longitud": -0.1345}', 'SO3', 78.0),
('44:5C:2V:3S:4F:6I', '2024-12-13 02:00:00', '{"latitud": 38.7775, "longitud": -0.1340}', 'NO2', 88.0),
('44:5C:2V:3S:4F:6I', '2024-12-13 03:00:00', '{"latitud": 38.7777, "longitud": -0.1335}', 'O3', 184.0);